/*
 * Copyright 2014-2016 CyberVision, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import "ConfigurationGen.h"

/*
 * AUTO-GENERATED CODE
 */

@implementation KAADeviceType

- (instancetype)init {
    self = [super init];
    if (self) {
                                        self.__uuid = [KAAUnion unionWithBranch:KAA_UNION_FIXED_OR_NULL_BRANCH_1];
                }
    return self;
}

- (instancetype)initWithActive:(BOOL)active __uuid:(KAAUnion *)__uuid {
    self = [super init];
    if (self) {
        self.active = active;
        self.__uuid = __uuid;
    }
    return self;
}

+ (NSString *)FQN {
    return @"org.kaaproject.kaa.demo2.activation.DeviceType";
}

- (void)serialize:(avro_writer_t)writer {
    [self.utils serializeBoolean:@(self.active) to:writer];
    [self serialize__uuid:self.__uuid to:writer];
}

- (size_t)getSize {
    size_t recordSize = 0;
        recordSize += [self.utils getBooleanSize:@(self.active)];
        recordSize += [self get__uuidSize:self.__uuid];
    return recordSize;
}

- (void)deserialize:(avro_reader_t)reader {
    self.active = [[self.utils deserializeBoolean:reader] boolValue];
    self.__uuid = [self deserialize__uuid:reader];
}


- (void)serialize__uuid:(KAAUnion *)kaaUnion to:(avro_writer_t)writer {

    if (kaaUnion) {
        avro_binary_encoding.write_long(writer, kaaUnion.branch);

        switch (kaaUnion.branch) {
        case KAA_UNION_FIXED_OR_NULL_BRANCH_0:
        {
            if (kaaUnion.data) {
                [self.utils serializeFixed:kaaUnion.data to:writer];
            }
            break;
        }
        default:
            break;
        }
    }
}

- (size_t)get__uuidSize:(KAAUnion *)kaaUnion {
    size_t unionSize = [self.utils getLongSize:@(kaaUnion.branch)];
    if (kaaUnion) {
        switch (kaaUnion.branch) {
        case KAA_UNION_FIXED_OR_NULL_BRANCH_0:
        {
            if (kaaUnion.data) {
                unionSize += [self.utils getFixedSize:kaaUnion.data];
            }
            break;
        }
        default:
            break;
        }
    }
    return unionSize;
}

- (KAAUnion *)deserialize__uuid:(avro_reader_t)reader {

    KAAUnion *kaaUnion = [[KAAUnion alloc] init];

        int64_t branch;
        avro_binary_encoding.read_long(reader, &branch);
        kaaUnion.branch = (int)branch;

        switch (kaaUnion.branch) {
        case KAA_UNION_FIXED_OR_NULL_BRANCH_0: {
            NSNumber *size = @(16);
            kaaUnion.data = [self.utils deserializeFixed:reader size:size];
            break;
        }
        default:
            break;
        }

    return kaaUnion;
}

@end
