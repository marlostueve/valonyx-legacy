/*
 * Copyright 2014-2016 CyberVision, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef KaaDefaults_h
#define KaaDefaults_h

#define BUILD_VERSION           @"0.9.0"
#define BUILD_COMMIT_HASH       @""
#define TRANSPORT_POLL_DELAY    @"0"
#define TRANSPORT_POLL_PERIOD   @"10"
#define TRANSPORT_POLL_UNIT     @"1"
#define STATE_FILE_LOCATION     @"state.properties"
#define SDK_TOKEN               @"Gl_JNIEULuytf8E0WhWhBKTSG2k"
#define CONFIG_DATA_DEFAULT     @"AACPftNRP5xDdIwQ3QhZSujL"

static NSString *CONFIG_SCHEMA_DEFAULT = @"eyJ0eXBlIjoiYXJyYXkiLCJpdGVtcyI6eyJ0eXBlIjoicmVjb3JkIiwibmFtZSI6ImRlbHRhVCIsIm5hbWVzcGFjZSI6Im9yZy5rYWFwcm9qZWN0LmNvbmZpZ3VyYXRpb24iLCJmaWVsZHMiOlt7Im5hbWUiOiJkZWx0YSIsInR5cGUiOlt7InR5cGUiOiJyZWNvcmQiLCJuYW1lIjoiRGV2aWNlVHlwZSIsIm5hbWVzcGFjZSI6Im9yZy5rYWFwcm9qZWN0LmthYS5kZW1vMi5hY3RpdmF0aW9uIiwiZmllbGRzIjpbeyJuYW1lIjoiYWN0aXZlIiwidHlwZSI6WyJib29sZWFuIix7InR5cGUiOiJlbnVtIiwibmFtZSI6InVuY2hhbmdlZFQiLCJuYW1lc3BhY2UiOiJvcmcua2FhcHJvamVjdC5jb25maWd1cmF0aW9uIiwic3ltYm9scyI6WyJ1bmNoYW5nZWQiXX1dLCJieV9kZWZhdWx0IjpmYWxzZX0seyJuYW1lIjoiX191dWlkIiwidHlwZSI6eyJ0eXBlIjoiZml4ZWQiLCJuYW1lIjoidXVpZFQiLCJuYW1lc3BhY2UiOiJvcmcua2FhcHJvamVjdC5jb25maWd1cmF0aW9uIiwic2l6ZSI6MTZ9LCJkaXNwbGF5TmFtZSI6IlJlY29yZCBJZCIsImZpZWxkQWNjZXNzIjoicmVhZF9vbmx5In1dfV19XX19";
static NSString *BOOTSTRAP_SERVERS = @"-1835393002:-73777936:1:AAABJjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMuJ45Qt+CZebLGQ5n74hLTH7pnWtZrYmkDSSlDjYlNWQmpGoC6lkS2hACQ3Ww8p2PgsFlHLhLxMilHipRpCWuwLHyNXaDdSEHAP8/kwSdpOJfo330mmRhu9zHzIwrRiwu90mnXECua04Phu3fvtcsDlyoLf3EaW0YaFx5kPRniCtn3l7BZClJgfa8jQktsCjwgo5MdCJCChEi4nre/1pg8dluU5rOQnYgFPXkTBcz55hjDjmWtsMh8OJjARmqNbD9AwAq0JXY1vRcORpNOyI6bJiiyXaC4Cs5M6G9be1iFlI/t/ga7GzoMfrTrmmn4KCgP1Y5Q7M7dbx8lG7aQlPCMCAwEAAQAAAB5sbm4xMzgzLmF1cy51cy5zaXRlcHJvdGVjdC5jb20AACah;-1835393002:1456013202:1:AAABJjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMuJ45Qt+CZebLGQ5n74hLTH7pnWtZrYmkDSSlDjYlNWQmpGoC6lkS2hACQ3Ww8p2PgsFlHLhLxMilHipRpCWuwLHyNXaDdSEHAP8/kwSdpOJfo330mmRhu9zHzIwrRiwu90mnXECua04Phu3fvtcsDlyoLf3EaW0YaFx5kPRniCtn3l7BZClJgfa8jQktsCjwgo5MdCJCChEi4nre/1pg8dluU5rOQnYgFPXkTBcz55hjDjmWtsMh8OJjARmqNbD9AwAq0JXY1vRcORpNOyI6bJiiyXaC4Cs5M6G9be1iFlI/t/ga7GzoMfrTrmmn4KCgP1Y5Q7M7dbx8lG7aQlPCMCAwEAAQAAAB5sbm4xMzgzLmF1cy51cy5zaXRlcHJvdGVjdC5jb20AACag;";

#endif /* KaaDefaults_h */
